package com.wwt.test;



public class LogserverTest {
	
	public static void main(String[] args) throws Exception {
		
		HttpClientStack client = new HttpClientStack();
		Boolean success = client.setLogUrl("http://140.206.176.12:8060/logserver/unicome").setEventKey("uniLogin").execute("\"date\":\"2014年8月11日15:07:45\"");//内容为 json字符串
		System.out.println(success);
	}
	
	
}
